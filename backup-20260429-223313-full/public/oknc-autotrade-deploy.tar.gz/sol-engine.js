/**
 * sol-engine.js — Solana 链交易引擎
 *
 * 使用 Jupiter API v6 进行代币兑换
 * 支持 SOL → 代币（买入）和 代币 → SOL（卖出）
 */
import { Connection, PublicKey, LAMPORTS_PER_SOL, VersionedTransaction } from '@solana/web3.js';
import { getAssociatedTokenAddress, getAccount } from '@solana/spl-token';
import bs58 from 'bs58';
import fetch from 'node-fetch';
import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, 'data');
const LOG_FILE = path.join(DATA_DIR, 'sol-log.json');

// === 常量 ===
const WSOL_MINT = 'So11111111111111111111111111111111111111112';
const JUPITER_QUOTE_API = 'https://quote-api.jup.ag/v6/quote';
const JUPITER_SWAP_API = 'https://quote-api.jup.ag/v6/swap';
const DEFAULT_SLIPPAGE_BPS = 100; // 1%
const JUPITER_PRICE_API = 'https://quote-api.jup.ag/v6/price';

// Solana RPC
const SOL_RPC = process.env.SOL_RPC || 'https://api.mainnet-beta.solana.com';

// === 引擎状态 ===
let connection = null;
let walletKeypair = null;
let isInitialized = false;

/**
 * 获取 SOL 的 USD 价格
 */
let solPriceCache = { price: 0, time: 0 };
async function getSOLPriceUSD() {
  if (Date.now() - solPriceCache.time < 30000 && solPriceCache.price > 0) {
    return solPriceCache.price;
  }
  try {
    const resp = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd');
    if (resp.ok) {
      const data = await resp.json();
      solPriceCache = { price: data.solana.usd, time: Date.now() };
      return data.solana.usd;
    }
  } catch {}
  return 0;
}

/**
 * 初始化 SOL 引擎
 * @param {string} privateKey - base58 编码的 Solana 私钥
 */
export async function initSolEngine(privateKey = null) {
  const pk = privateKey || process.env.SOL_PRIVATE_KEY;
  if (!pk) {
    throw new Error('SOL 私钥未提供，请在 .env 配置 SOL_PRIVATE_KEY 或在钱包中导入');
  }

  connection = new Connection(SOL_RPC, 'confirmed');

  let secretKey;
  try {
    const decoded = bs58.decode(pk.trim());
    if (decoded.length === 64) secretKey = decoded;
    else if (decoded.length === 32) secretKey = Keypair.fromSeed(decoded).secretKey;
    else throw new Error('无效的 SOL 私钥长度');
  } catch (e) {
    if (e.message && e.message.includes('无效')) throw e;
    // JSON 数组格式
    try {
      const arr = JSON.parse(pk.trim());
      secretKey = new Uint8Array(arr);
    } catch {
      throw new Error('无法解析 SOL 私钥');
    }
  }

  const { Keypair } = await import('@solana/web3.js');
  walletKeypair = Keypair.fromSecretKey(secretKey);
  isInitialized = true;
  console.log(`[SolEngine] ✅ 初始化完成，钱包: ${walletKeypair.publicKey.toBase58()}`);
  return walletKeypair.publicKey.toBase58();
}

export function isSolInitialized() { return isInitialized; }

export function getSolWalletAddress() {
  return walletKeypair?.publicKey?.toBase58() || null;
}

/**
 * 获取 SOL 余额（native）
 */
export async function getSolBalance() {
  if (!connection || !walletKeypair) {
    console.log('[SolEngine] ⚠️ 引擎未初始化，尝试初始化...');
    return 0;
  }
  try {
    const balance = await connection.getBalance(walletKeypair.publicKey);
    return balance / LAMPORTS_PER_SOL;
  } catch (err) {
    console.error('[SolEngine] 获取SOL余额失败:', err.message);
    return 0;
  }
}

/**
 * 获取 SPL 代币余额
 * @param {string} tokenMint - 代币 Mint 地址
 */
export async function getTokenBalance(tokenMint) {
  if (!connection || !walletKeypair) return 0;
  try {
    const mintPubkey = new PublicKey(tokenMint);
    const tokenAccount = await getAssociatedTokenAddress(mintPubkey, walletKeypair.publicKey);
    try {
      const accountInfo = await getAccount(connection, tokenAccount);
      const decimals = 6; // 默认，如果能从链上获取更好
      return Number(accountInfo.amount) / Math.pow(10, decimals);
    } catch {
      return 0; // 没有代币账户
    }
  } catch {
    return 0;
  }
}

/**
 * 获取 SPL 代币余额（返回原始 wei 级数量 + decimals）
 */
export async function getTokenBalanceRaw(tokenMint) {
  if (!connection || !walletKeypair) return { amount: 0n, decimals: 6 };
  try {
    const mintPubkey = new PublicKey(tokenMint);
    const tokenAccount = await getAssociatedTokenAddress(mintPubkey, walletKeypair.publicKey);
    try {
      const accountInfo = await getAccount(connection, tokenAccount);
      // 获取 decimals（从链上获取）
      let decimals = 6;
      try {
        const mintInfo = await connection.getAccountInfo(mintPubkey);
        if (mintInfo && mintInfo.data) {
          decimals = mintInfo.data[44]; // decimals is at offset 44 in SPL mint
        }
      } catch {}
      return { amount: accountInfo.amount, decimals };
    } catch {
      return { amount: 0n, decimals: 6 };
    }
  } catch {
    return { amount: 0n, decimals: 6 };
  }
}

/**
 * 从 Jupiter API 获取代币价格
 * @param {string} tokenMint - 代币 mint 地址
 */
export async function getJupiterPrice(tokenMint) {
  try {
    const resp = await fetch(`${JUPITER_PRICE_API}?ids=${tokenMint}&vsToken=${WSOL_MINT}`);
    if (resp.ok) {
      const data = await resp.json();
      if (data.data && data.data[tokenMint]) {
        const priceInSOL = parseFloat(data.data[tokenMint].price);
        const solPrice = await getSOLPriceUSD();
        return { priceInSOL, priceInUSD: priceInSOL * solPrice };
      }
    }
  } catch {}
  return { priceInSOL: 0, priceInUSD: 0 };
}

/**
 * 获取 Jupiter 报价
 * @param {string} inputMint - 输入代币 mint
 * @param {string} outputMint - 输出代币 mint
 * @param {number} amount - 输入数量（人类可读单位）
 * @param {number} slippageBps - 滑点 (bps, 默认100=1%)
 * @param {number} decimals - 输入代币精度
 */
export async function getQuote(inputMint, outputMint, amount, slippageBps = DEFAULT_SLIPPAGE_BPS, decimals = 9) {
  const amountRaw = Math.floor(amount * Math.pow(10, decimals));
  const url = `${JUPITER_QUOTE_API}?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amountRaw}&slippageBps=${slippageBps}`;

  const resp = await fetch(url);
  if (!resp.ok) {
    throw new Error(`Jupiter 报价错误: ${resp.status}`);
  }
  return resp.json();
}

/**
 * 执行买入：SOL → 代币
 * @param {string} tokenMint - 代币 mint 地址
 * @param {number} amountSOL - 买入 SOL 数量
 * @param {number} slippageBps - 滑点 (bps)
 */
export async function executeSolBuy(tokenMint, amountSOL, slippageBps = DEFAULT_SLIPPAGE_BPS) {
  if (!isInitialized) throw new Error('SOL 引擎未初始化');

  const solBalance = await getSolBalance();
  if (solBalance < amountSOL + 0.001) {
    throw new Error(`SOL 余额不足: ${solBalance.toFixed(4)} SOL，需要 ${amountSOL} SOL + gas`);
  }

  // 1. 获取报价
  const amountLamports = Math.floor(amountSOL * LAMPORTS_PER_SOL);
  const quote = await getQuote(WSOL_MINT, tokenMint, amountSOL, slippageBps, 9);

  if (!quote.routePlan || quote.routePlan.length === 0) {
    throw new Error('Jupiter 未找到交易路径');
  }

  // 2. 构建 swap 交易
  const swapPayload = {
    quoteResponse: quote,
    userPublicKey: walletKeypair.publicKey.toBase58(),
    wrapAndUnwrapSol: true,
    dynamicComputeUnitLimit: true,
    prioritizationFeeLamports: {
      priorityLevelWithMaxLamports: {
        maxLamports: 100000,
        priorityLevel: 'medium',
      },
    },
  };

  const swapResp = await fetch(JUPITER_SWAP_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(swapPayload),
  });

  if (!swapResp.ok) {
    const errData = await swapResp.text();
    throw new Error(`Jupiter swap 构建失败: ${swapResp.status} - ${errData}`);
  }

  const swapData = await swapResp.json();

  // 3. 反序列化并签名
  const txBuffer = Buffer.from(swapData.swapTransaction, 'base64');
  const transaction = VersionedTransaction.deserialize(txBuffer);
  transaction.sign([walletKeypair]);

  // 4. 发送交易
  const txHash = await connection.sendTransaction(transaction, {
    skipPreflight: false,
    preflightCommitment: 'confirmed',
  });

  console.log(`[SolEngine] 买入交易已发送: ${txHash}`);

  // 5. 等待确认
  const confirmation = await connection.confirmTransaction(txHash, 'confirmed');
  if (confirmation.value.err) {
    throw new Error(`交易失败: ${JSON.stringify(confirmation.value.err)}`);
  }

  // 6. 计算实际获得的代币数量
  const outAmount = parseFloat(quote.outAmount) / Math.pow(10, quote.outputMint.decimals || 6);
  const solPrice = await getSOLPriceUSD();
  const actualPriceUSD = amountSOL > 0 && outAmount > 0
    ? (amountSOL / outAmount) * solPrice
    : 0;

  const result = {
    type: 'buy',
    chain: 'sol',
    amountIn: amountSOL,
    symbolIn: 'SOL',
    amountOut: outAmount,
    symbolOut: tokenMint.slice(0, 6) + '...',
    actualPriceUSD,
    txHash,
    gasUsed: 0,
  };
  appendSolLog(result);
  return result;
}

/**
 * 执行卖出：代币 → SOL
 * @param {string} tokenMint - 代币 mint 地址
 * @param {number} amountToken - 卖出代币数量
 * @param {number} tokenDecimals - 代币精度
 * @param {number} slippageBps - 滑点 (bps)
 */
export async function executeSolSell(tokenMint, amountToken, tokenDecimals = 6, slippageBps = DEFAULT_SLIPPAGE_BPS) {
  if (!isInitialized) throw new Error('SOL 引擎未初始化');

  // 获取链上实际余额
  const rawBalance = await getTokenBalanceRaw(tokenMint);
  const sellAmountRaw = BigInt(Math.floor(amountToken * Math.pow(10, tokenDecimals)));
  const actualSellAmount = sellAmountRaw < rawBalance.amount ? sellAmountRaw : rawBalance.amount;

  if (rawBalance.amount < 1n) {
    throw new Error(`代币链上余额为 0，无法卖出`);
  }

  // 1. 获取报价（用实际 wei 值）
  const amountInRaw = actualSellAmount.toString();
  const quoteUrl = `${JUPITER_QUOTE_API}?inputMint=${tokenMint}&outputMint=${WSOL_MINT}&amount=${amountInRaw}&slippageBps=${slippageBps}`;
  const quoteResp = await fetch(quoteUrl);
  if (!quoteResp.ok) throw new Error(`Jupiter 报价错误: ${quoteResp.status}`);
  const quote = await quoteResp.json();

  if (!quote.routePlan || quote.routePlan.length === 0) {
    throw new Error('Jupiter 未找到交易路径');
  }

  // 2. 构建 swap 交易
  const swapPayload = {
    quoteResponse: quote,
    userPublicKey: walletKeypair.publicKey.toBase58(),
    wrapAndUnwrapSol: true,
    dynamicComputeUnitLimit: true,
    prioritizationFeeLamports: {
      priorityLevelWithMaxLamports: {
        maxLamports: 100000,
        priorityLevel: 'medium',
      },
    },
  };

  const swapResp = await fetch(JUPITER_SWAP_API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(swapPayload),
  });

  if (!swapResp.ok) {
    const errData = await swapResp.text();
    throw new Error(`Jupiter swap 构建失败: ${swapResp.status} - ${errData}`);
  }

  const swapData = await swapResp.json();

  // 3. 签名并发送
  const txBuffer = Buffer.from(swapData.swapTransaction, 'base64');
  const transaction = VersionedTransaction.deserialize(txBuffer);
  transaction.sign([walletKeypair]);

  const txHash = await connection.sendTransaction(transaction, {
    skipPreflight: false,
    preflightCommitment: 'confirmed',
  });

  console.log(`[SolEngine] 卖出交易已发送: ${txHash}`);

  const confirmation = await connection.confirmTransaction(txHash, 'confirmed');
  if (confirmation.value.err) {
    throw new Error(`交易失败: ${JSON.stringify(confirmation.value.err)}`);
  }

  const outAmount = parseFloat(quote.outAmount) / LAMPORTS_PER_SOL;
  const result = {
    type: 'sell',
    chain: 'sol',
    amountIn: Number(actualSellAmount) / Math.pow(10, tokenDecimals),
    symbolIn: tokenMint.slice(0, 6) + '...',
    amountOut: outAmount,
    symbolOut: 'SOL',
    txHash,
    gasUsed: 0,
  };
  appendSolLog(result);
  return result;
}

/**
 * 模拟买入（仅报价，不执行交易）
 */
export async function simulateSolBuy(tokenMint, amountSOL) {
  if (!isInitialized) return { buyTaxPct: null, isHoneypot: null, error: '引擎未初始化' };
  try {
    const quote = await getQuote(WSOL_MINT, tokenMint, amountSOL, DEFAULT_SLIPPAGE_BPS, 9);
    const expectedOut = parseFloat(quote.outAmount) / Math.pow(10, quote.outputMint?.decimals || 6);
    // Jupiter Route 无法直接返回税费，用预期输出和预期价格估算
    const routePriceImpact = parseFloat(quote.routePlan?.[0]?.percent || 0) || 0;
    return {
      buyTaxPct: Math.min(routePriceImpact * 100, 20),
      isHoneypot: false,
      expectedOut,
      priceImpactPct: routePriceImpact * 100,
    };
  } catch (err) {
    return { buyTaxPct: null, isHoneypot: null, error: err.message };
  }
}

/**
 * 模拟卖出（仅报价，不执行交易）
 */
export async function simulateSolSell(tokenMint, amountToken, decimals = 6) {
  if (!isInitialized) return { sellTaxPct: null, isHoneypot: null, error: '引擎未初始化' };
  try {
    const amountRaw = Math.floor(amountToken * Math.pow(10, decimals));
    const quoteUrl = `${JUPITER_QUOTE_API}?inputMint=${tokenMint}&outputMint=${WSOL_MINT}&amount=${amountRaw}&slippageBps=${DEFAULT_SLIPPAGE_BPS}`;
    const resp = await fetch(quoteUrl);
    if (!resp.ok) return { sellTaxPct: null, isHoneypot: null, error: `Jupiter 报价失败: ${resp.status}` };
    const quote = await resp.json();
    const expectedOut = parseFloat(quote.outAmount) / LAMPORTS_PER_SOL;
    const routePriceImpact = parseFloat(quote.routePlan?.[0]?.percent || 0) || 0;
    return {
      sellTaxPct: Math.min(routePriceImpact * 100, 20),
      isHoneypot: false,
      expectedOut,
      priceImpactPct: routePriceImpact * 100,
    };
  } catch (err) {
    return { sellTaxPct: null, isHoneypot: null, error: err.message };
  }
}

// === 日志 ===
function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
}

function appendSolLog(entry) {
  ensureDataDir();
  let logs = [];
  if (fs.existsSync(LOG_FILE)) {
    try { logs = JSON.parse(fs.readFileSync(LOG_FILE, 'utf-8')); }
    catch { /* 忽略 */ }
  }
  logs.push({ ...entry, time: new Date().toISOString() });
  const THREE_DAYS_MS = 3 * 24 * 60 * 60 * 1000;
  const cutoff = Date.now() - THREE_DAYS_MS;
  logs = logs.filter(l => {
    const t = new Date(l.time).getTime();
    return !isNaN(t) && t >= cutoff;
  });
  if (logs.length > 2000) logs = logs.slice(-2000);
  fs.writeFileSync(LOG_FILE, JSON.stringify(logs, null, 2));
}

export function getSolRecentLogs(count = 50, offset = 0) {
  ensureDataDir();
  if (!fs.existsSync(LOG_FILE)) return { items: [], total: 0 };
  try {
    const logs = JSON.parse(fs.readFileSync(LOG_FILE, 'utf-8'));
    const reversed = [...logs].reverse();
    const items = reversed.slice(offset, offset + count);
    return { items, total: logs.length };
  } catch {
    return { items: [], total: 0 };
  }
}

/**
 * 获取综合链上数据（代币分析用）
 */
export async function analyzeSolToken(tokenMint) {
  try {
    const mintPubkey = new PublicKey(tokenMint);
    const acctInfo = await connection.getAccountInfo(mintPubkey);
    if (!acctInfo) {
      return { error: '该地址不是有效的 Solana 代币 Mint' };
    }
    // 从 Mint 数据解析基本信息
    const decimals = acctInfo.data[44];
    const supplyBuffer = acctInfo.data.slice(36, 44);
    const supply = supplyBuffer.readBigUInt64LE(0);
    const supplyParsed = Number(supply) / Math.pow(10, decimals);

    // Jupiter 价格
    const priceInfo = await getJupiterPrice(tokenMint);

    return {
      decimals,
      supplyFormatted: supplyParsed.toLocaleString(),
      priceSOL: priceInfo.priceInSOL,
      priceUSD: priceInfo.priceInUSD,
    };
  } catch (err) {
    return { error: err.message };
  }
}
