#!/bin/bash
# OKNC 合约自动交易系统 — 一键部署脚本
set -e

echo "=========================================="
echo "OKNC 合约自动交易系统 v2.0 — 一键部署"
echo "=========================================="

# 检查root
if [ "$EUID" -ne 0 ]; then
  echo "❌ 请以root身份运行: sudo bash deploy.sh"
  exit 1
fi

# 检查Node.js
if ! command -v node &> /dev/null; then
  echo "📦 安装 Node.js 18..."
  curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
  apt-get install -y nodejs
fi

NODE_VER=$(node -v)
echo "✅ Node.js: $NODE_VER"

# 进入项目目录
cd "$(dirname "$0")"

# 安装依赖
echo "📦 安装 npm 依赖..."
npm install

# 检查密钥配置
if [ ! -f "data/exchange-keys.json" ]; then
  echo ""
  echo "⚠️  未检测到交易所密钥配置！"
  echo "   请编辑 data/exchange-keys.json 填写您的币安API密钥"
  echo "   参考模板: data/exchange-keys.template.json"
  echo ""
  # 从模板创建
  if [ -f "data/exchange-keys.template.json" ]; then
    cp data/exchange-keys.template.json data/exchange-keys.json
    echo "   已从模板创建，请修改: nano data/exchange-keys.json"
  fi
fi

# 检查.env
if [ ! -f ".env" ]; then
  if [ -f ".env.template" ]; then
    cp .env.template .env
    echo "⚠️  请编辑 .env 填写认证密码: nano .env"
  fi
fi

# 安装systemd服务
echo "🔧 安装 Systemd 服务..."
cp oknc-autotrade.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable oknc-autotrade.service

echo ""
echo "=========================================="
echo "✅ 部署完成！"
echo "=========================================="
echo ""
echo "下一步："
echo "  1. 编辑密钥: nano data/exchange-keys.json"
echo "  2. 编辑密码: nano .env"
echo "  3. 启动服务: systemctl start oknc-autotrade"
echo "  4. 查看日志: journalctl -u oknc-autotrade -f"
echo "  5. 访问面板: http://服务器IP:3000"
echo ""
