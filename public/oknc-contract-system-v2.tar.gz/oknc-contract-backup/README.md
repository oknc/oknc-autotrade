# OKNC 合约自动交易系统 v2.0

币安合约(Binance Futures)自动交易系统 — 自适应市场状态、ATR动态止盈止损、多风格策略。

---

## 📦 文件结构

```
oknc-contract-backup/
├── cex/                        # 合约交易核心代码
│   ├── cex-engine.js           # 引擎：交易所API封装、风格预设、仓位管理
│   ├── cex-strategy.js         # 策略：信号生成、追踪止盈、趋势/均值回归
│   ├── cex-adaptive.js         # 自适应：市场状态检测(ADX)、ATR动态止损、Kelly仓位
│   ├── cex-data.js             # 数据：K线缓存、WebSocket流
│   ├── cex-logger.js           # 日志：操作日志系统
│   ├── risk-manager.js         # 风控：熔断、清算自动减仓、日亏损冻结
│   └── server.js               # 服务：Express Web服务器 + API路由
├── public/
│   └── contract.html           # 合约交易前端面板（K线图、操作日志）
├── scripts/
│   └── contract-pnl-report.py  # 每日盈亏损益报告推送到微信
├── nginx/
│   ├── trade.oknc.club.conf    # 交易面板Nginx反向代理配置
│   └── oknc.club.conf          # 主站Nginx配置（参考）
├── data/
│   └── exchange-keys.template.json  # 交易所密钥模板（需填写真实密钥）
├── deploy.sh                   # 一键部署脚本
├── .env.template               # 环境变量模板
├── oknc-autotrade.service      # Systemd服务文件
├── package.json                # Node.js依赖
└── README.md                   # 本文件
```

---

## 🚀 部署指南

### 前提条件

- Linux 服务器（Ubuntu 20.04+ / Debian 11+）
- Node.js 18+
- Nginx（可选，用于域名+HTTPS）
- 币安合约API密钥（需开通合约交易权限）

### 1. 上传代码

```bash
# 使用 scp 上传到服务器
scp oknc-contract-backup.tar.gz root@你的服务器IP:/root/

# 解压
cd /root
tar xzf oknc-contract-backup.tar.gz
```

### 2. 安装依赖

```bash
cd /root/autotrade
npm install
```

### 3. 配置密钥

```bash
# 编辑交易所密钥
nano /root/autotrade/data/exchange-keys.json
```

格式：
```json
[
  {
    "exchangeId": "binance",
    "isActive": true,
    "apiKey": "你的币安API Key",
    "secret": "你的币安Secret Key",
    "password": "",
    "label": "主账户"
  }
]
```

> ⚠️ API密钥需开通：`允许合约交易`、`开启读取`。建议限制IP白名单。

### 4. 配置认证密码

编辑 `/root/autotrade/.env`：
```
AUTH_PASSWORD=你的管理员密码
AUTH_PASSWORD_READONLY=你的只读密码
PORT=3000
```

### 5. 配置Systemd服务

```bash
cp /root/autotrade/oknc-autotrade.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable oknc-autotrade.service
systemctl start oknc-autotrade.service

# 检查状态
systemctl status oknc-autotrade.service
journalctl -u oknc-autotrade.service -f
```

### 6.（可选）配置Nginx反向代理+HTTPS

```bash
# 复制Nginx配置
cp /root/autotrade/nginx/trade.oknc.club.conf /etc/nginx/sites-available/

# 修改域名
sed -i 's/trade.oknc.club/你的域名/g' /etc/nginx/sites-available/trade.oknc.club.conf

# 启用配置
ln -s /etc/nginx/sites-available/trade.oknc.club.conf /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx

# 申请SSL证书
certbot --nginx -d 你的域名
```

### 7. 访问控制面板

浏览器打开 `http://你的服务器IP:3000` 或 `https://你的域名`

---

## 🎮 使用说明

### 三套策略风格

| 风格 | 杠杆 | 仓位比例 | 止损 | 止盈 | 信号确认 | 适用场景 |
|------|------|---------|------|------|---------|---------|
| 🟢 保守 | 2x | 5% | 3% | 8% | 2次确认 | 低风险新手 |
| 🟡 稳健 | 5x | 15% | 5% | 15% | 1次确认 | 中等风险 |
| 🔴 激进 | 10x | 30% | 8% | 10% | 1次确认 | 高收益追求 |

### 核心功能

- **自适应市场状态**：ADX检测趋势/震荡/波动市场，自动调整信号权重
- **ATR动态止盈止损**：根据波动率自动调整止损距离（低波动≥2.5x ATR）
- **Kelly仓位管理**：基于历史胜率自动调整头寸大小
- **追踪止盈**：盈利时逐步上移止损，锁定利润
- **分段止盈**：达到70%止盈目标时平50%仓位，剩余仓位保本追踪
- **趋势重入**：止盈后趋势仍强时，半仓追入
- **止损冷却**：止损后15分钟内不重复开仓该币种
- **熔断保护**：清算距离<3%时平所有仓位

### 操作日志

面板右上角「操作日志」可查看所有系统操作记录（最多2000条，每页20条）。

---

## 🔧 技术架构

```
┌─────────────┐     ┌──────────────┐     ┌──────────────────┐
│  前端面板    │────▶│  Express API  │────▶│  cex-engine.js    │
│ contract.html│     │  server.js    │     │  (交易所封装)    │
└─────────────┘     └──────┬───────┘     └────────┬─────────┘
                           │                       │
                    ┌──────▼───────┐      ┌────────▼─────────┐
                    │ cex-strategy │      │  Binance Futures  │
                    │ (策略引擎)    │◀────▶│  (REST + WebSocket)│
                    └──────┬───────┘      └──────────────────┘
                           │
                    ┌──────▼───────┐
                    │ cex-adaptive │
                    │ (自适应进化)  │
                    └──────────────┘
```

### 数据流

1. WebSocket实时行情 → `cex-data.js` 缓存K线
2. 每5分钟 `evaluateStrategy()` 生成交易信号
3. 每30秒 `checkPositions()` 检查持仓状态 + 追踪止盈
4. 信号触发 → `openPosition()` 开仓 + Algo API设置止盈止损
5. 风控模块 `risk-manager.js` 监控清算距离 + 日亏损

---

## 📊 每日盈亏报告

系统每日8:00通过cron推送盈亏报告到微信：

```bash
# 每日报告依赖脚本
/root/autotrade/scripts/contract-pnl-report.py
```

---

## 🔄 版本历史

| 日期 | 版本 | 变更 |
|------|------|------|
| 2026-05-05 | v2.0 | 大版本重构：自适应市场状态、ATR动态止损、Kelly仓位、分段止盈、趋势重入 |
| 2026-05-05 | v2.0.1 | 修复：追踪止盈TP浮点精度Bug（newTP锚定开仓价+toFixed(2)防抖） |
| 2026-05-05 | v2.0.2 | 修复：条件单重复创建（checkPositions不再重复创建SL/TP） |
| 2026-05-05 | v2.0.3 | 优化：restCreateAlgoOrder增加priceToPrecision精度格式+重试机制；ATR降级止损乘数最低2.5x |
