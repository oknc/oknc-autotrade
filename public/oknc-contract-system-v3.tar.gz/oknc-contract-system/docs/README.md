# OKNC 全栈交易系统 — 部署指南

## 系统架构

```
trade.oknc.club (Nginx 443)
  ├── /              → 菜单面板                     (/var/www/trade-menu/)
  ├── /contract/     → AI合约自动交易系统 (端口3000)  (/root/autotrade/)
  ├── /web3/         → 全链链上交易系统 (端口3001)    (/root/web3-trading/)
  └── /mms/          → 全自动做市交易系统 (端口3002)  (/root/autotrade/mms/)
```

## 目录结构

```
code/
  ├── server.js              Express主服务 + API路由 (合约+链上)
  ├── engine.js              Web3交易引擎
  ├── sol-engine.js          Solana交易引擎
  ├── cex-engine.js          币安合约引擎
  ├── cex-strategy.js        策略引擎 (持仓/止盈止损/追踪)
  ├── cex-adaptive.js        自适应市场状态
  ├── risk-manager.js        风控引擎
  ├── screener.js            DexScreener扫描
  ├── wallet-manager.js      多钱包管理
  ├── pair-scanner.js        BSC链上新池扫描
  ├── gecko-scanner.js       GeckoTerminal扫描
  ├── public/                前端静态文件
  │   ├── contract.html      合约交易面板
  │   ├── index.html         菜单页
  │   └── oknc-logo.png      品牌图标
  ├── web3-service/          全链链上交易系统 (分离服务)
  │   ├── server.js          独立服务主入口
  │   ├── engine.js          Web3交易引擎
  │   └── public/index.html  前端面板
  ├── mms/                   做市系统 (占位)
  ├── scripts/               定时任务脚本
  └── .env.example           环境变量模板

config/
  ├── .env.example                  环境变量 (脱敏)
  ├── nginx-enabled.conf            站点配置
  ├── trade.oknc.club.conf          站点配置 (sites-available)
  ├── oknc-autotrade.service        合约系统服务
  ├── web3-autotrade.service        全链系统服务
  └── mms-autotrade.service         做市系统服务

docs/
  └── README.md                     本文件
```

## 部署步骤

### 1. 环境准备 (Ubuntu 22.04+)

```bash
# 安装 Node.js v18+
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs nginx certbot python3-certbot-nginx

# 验证
node -v   # >= v18
npm -v
```

### 2. 部署合约系统 (port 3000)

```bash
# 创建目录
sudo mkdir -p /root/autotrade
# 上传 code/ 内容到 /root/autotrade/
sudo cp -r code/* /root/autotrade/
cd /root/autotrade

# 复制并配置环境变量
sudo cp .env.example .env
sudo nano .env   # 设置密码、密钥等

# 安装依赖
npm install

# 安装 systemd 服务
sudo cp /root/autotrade-backup/config/oknc-autotrade.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable oknc-autotrade.service
sudo systemctl start oknc-autotrade.service

# 查看状态
sudo systemctl status oknc-autotrade.service
sudo journalctl -u oknc-autotrade.service -f
```

### 3. 部署全链系统 (port 3001)

```bash
# 创建目录  
sudo mkdir -p /root/web3-trading
sudo cp -r code/web3-service/* /root/web3-trading/
cd /root/web3-trading

# 依赖 + 服务
npm install
# 注意: 独立服务的 .env 需额外配置
sudo nano .env

sudo cp /root/autotrade-backup/config/web3-autotrade.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable web3-autotrade.service
sudo systemctl start web3-autotrade.service
```

### 4. 配置 Nginx

```bash
# 安装站点配置
sudo cp /root/autotrade-backup/config/nginx-enabled.conf /etc/nginx/sites-enabled/trade
sudo nginx -t
sudo systemctl reload nginx
```

### 5. SSL 证书 (新服务器)

```bash
sudo certbot --nginx -d trade.oknc.club
```

## API 接口文档

| 端点 | 方法 | 说明 |
|------|------|------|
| `/contract/api/auth/login` | POST | 登录 `{"password":"xxx"}` |
| `/contract/api/cex/strategy/start` | POST | 启动策略 |
| `/contract/api/cex/strategy/stop` | POST | 停止策略 |
| `/contract/api/cex/position/open` | POST | 手动开仓 |
| `/contract/api/cex/position/close` | POST | 手动平仓 |
| `/contract/api/cex/style` | POST | 切换风格 |
| `/contract/api/cex/status` | GET | 引擎状态 |

## 风格参数

| 风格 | 杠杆 | 止损 | 止盈 | 追踪激活 | 追踪步长 | 信号确认 |
|------|------|------|------|---------|---------|---------|
| 保守 | 2x | 5% | 8% | 6% | 3% | 2 |
| 稳健 | 5x | 3% | 15% | 8% | 5% | 1 |
| 激进 | 10x | 8% | 10% | 12% | 7% | 1 |

## 排查

```bash
# 服务日志
sudo journalctl -u oknc-autotrade.service -n 50 --no-pager
# 端口检查
ss -tlnp | grep -E "300[0-2]"
# Nginx测试
curl -sk https://trade.oknc.club/contract/
curl -sk https://trade.oknc.club/contract/api/cex/status
```

---

> 生成: 2026-05-05 | OKNC Contract Trading System v3
