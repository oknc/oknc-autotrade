/**
 * baw-integration.js — Binance Agentic Wallet 集成模块
 * 
 * 封装 baw CLI 调用，提供：
 * - 钱包状态/余额查询
 * - 代币推荐（基于链上数据分析）
 * - 代币兑换（market-order swap）
 */
import { execSync } from 'child_process';

// ============ BAW CLI 基础封装 ============

function runBaw(args) {
  try {
    const output = execSync(`baw ${args} --json 2>/dev/null`, {
      timeout: 15000,
      encoding: 'utf-8',
    });
    return JSON.parse(output);
  } catch (err) {
    // Try to parse partial output even on error
    if (err.stdout) {
      try { return JSON.parse(err.stdout); } catch {}
    }
    return { success: false, error: err.message };
  }
}

/** 检查 BAW 连接状态 */
export function getBawStatus() {
  return runBaw('wallet status');
}

/** 获取钱包地址 */
export function getBawAddress() {
  return runBaw('wallet address');
}

/** 获取 BSC 链余额 */
export function getBawBalance() {
  return runBaw('wallet balance');
}

/** 获取支持的链 */
export function getBawChains() {
  return runBaw('wallet chains');
}

/**
 * 获取兑换报价
 * @param {string} fromTokenQty - 输入数量
 * @param {string} fromToken - 源代币地址
 * @param {string} toToken - 目标代币地址
 * @param {number} slippage - 滑点百分比
 */
export function getBawQuote(fromTokenQty, fromToken, toToken, slippage = 'auto', binanceChainId = '56') {
  let cmd = `market-order quote --binanceChainId ${binanceChainId} --fromTokenQty ${fromTokenQty}`;
  cmd += ` --fromToken ${fromToken} --toToken ${toToken}`;
  if (slippage !== 'auto') cmd += ` --slippage ${slippage}`;
  return runBaw(cmd);
}

/**
 * 执行代币兑换（market-order swap）
 * @param {Object} opts
 * @param {string} opts.fromTokenQty - 输入数量
 * @param {string} opts.fromToken - 源代币地址
 * @param {string} opts.toToken - 目标代币地址
 * @param {string} opts.slippage - 滑点 ("auto" 或 0-100)
 * @param {boolean} opts.mev - MEV 保护
 * @param {string} opts.gasLevel - gas 级别 (LOW/MEDIUM/HIGH)
 */
export function execBawSwap(opts) {
  const { fromTokenQty, fromToken, toToken, slippage = 'auto', mev = true, gasLevel = 'HIGH', binanceChainId = '56' } = opts;
  let cmd = `market-order swap --binanceChainId ${binanceChainId}`;
  cmd += ` --fromTokenQty ${fromTokenQty}`;
  cmd += ` --fromToken ${fromToken}`;
  cmd += ` --toToken ${toToken}`;
  cmd += ` --slippage ${slippage}`;
  cmd += ` --mev ${mev}`;
  cmd += ` --gasLevel ${gasLevel}`;
  return runBaw(cmd);
}

// ============ BSC 代币推荐系统 ============

// BSC 知名代币地址（用于优先级评分）
const KNOWN_TOKENS = {
  '0x55d398326f99059ff775485246999027b3197955': { name: 'USDT', rank: 1 },
  '0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d': { name: 'USDC', rank: 1 },
  '0x1af3f329e8be154074d8769d1ffa4ee058b1dbc3': { name: 'DAI', rank: 1 },
  '0x7130d2a12b9bcbfae4f2634d864a1ee1ce3ead9c': { name: 'BTCB', rank: 1 },
  '0x2170ed0880ac9a755fd29b2688956bd959f933f8': { name: 'ETH', rank: 1 },
  '0x0e09fabb73bd3ade0a17ecc321fd13a19e81ce82': { name: 'CAKE', rank: 2 },
  '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c': { name: 'WBNB', rank: 1 },
};

// BSC 链上常用池/路由地址
const DEX_FACTORIES = {
  pancakeswap: '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73',
  biswap: '0x858E3312ed3A876947EA49d572A7C42DE08af7EE',
};

/**
 * 分析代币并生成推荐评分
 * @param {Object} token - 代币数据对象
 * @returns {Object} 评分结果
 */
function scoreToken(token) {
  let score = 0;
  const reasons = [];

  // 1. 流动性评分 (liquidity USD)
  const liquidity = parseFloat(token.liquidity?.usd) || 0;
  if (liquidity > 500000) { score += 30; reasons.push('💰 流动性充足 >$500K'); }
  else if (liquidity > 100000) { score += 20; reasons.push('💰 流动性中等 >$100K'); }
  else if (liquidity > 25000) { score += 10; reasons.push('💰 基础流动性 >$25K'); }
  else { score -= 10; reasons.push('⚠️ 流动性偏低'); }

  // 2. 交易量评分 (24h volume)
  const volume = parseFloat(token.volume?.h24) || 0;
  if (volume > 1000000) { score += 25; reasons.push('📊 高交易量 >$1M/24h'); }
  else if (volume > 200000) { score += 15; reasons.push('📊 活跃交易 >$200K/24h'); }
  else if (volume > 50000) { score += 8; reasons.push('📊 有交易量 >$50K/24h'); }
  else { score -= 5; reasons.push('📊 交易量偏低'); }

  // 3. 价格变动评分 (5m change)
  const priceChange = parseFloat(token.priceChange?.h5) || 0;
  const absChange = Math.abs(priceChange);
  if (absChange > 20) { score -= 10; reasons.push('⚠️ 价格波动剧烈 >20%/5m'); }
  else if (absChange > 5) { score -= 3; reasons.push('⚡ 价格活跃波动'); }
  else if (absChange < 1) { score += 5; reasons.push('📈 价格相对稳定'); }

  // 4. 交易对数量评分
  const pairCount = parseInt(token.pairCount) || 0;
  if (pairCount > 5) { score += 10; reasons.push('🔗 多交易对支持'); }
  else if (pairCount > 1) { score += 5; reasons.push('🔗 有多个交易对'); }

  // 5. 年龄评分 (避免蜜罐/土狗)
  const age = token.createdAt ? (Date.now() - new Date(token.createdAt).getTime()) / 86400000 : 0;
  if (age > 30) { score += 15; reasons.push('⏳ 上线超过30天'); }
  else if (age > 7) { score += 8; reasons.push('⏳ 上线超过7天'); }
  else if (age > 1) { score += 3; reasons.push('🆕 新代币 (<1天)'); }
  else { score += 0; }

  // 6. 知名代币加成
  const base = token.baseToken?.address?.toLowerCase() || '';
  if (KNOWN_TOKENS[base]) {
    score += 20;
    reasons.push('⭐ 知名代币');
  }

  // 7. 交易者数量 (如果数据可用)
  const txns = token.txns?.h24;
  if (txns) {
    const buys = parseInt(txns.buys) || 0;
    const sells = parseInt(txns.sells) || 0;
    const total = buys + sells;
    if (total > 1000) { score += 15; reasons.push(`👥 活跃交易 >${total}笔/24h`); }
    else if (total > 200) { score += 8; reasons.push(`👥 有交易活跃度 ${total}笔/24h`); }
    
    // 买卖比
    if (buys > 0 && sells > 0) {
      const ratio = buys / sells;
      if (ratio > 2) { score += 10; reasons.push(`📈 买方主导 (${ratio.toFixed(1)}:1)`); }
      else if (ratio > 1.2) { score += 5; reasons.push(`📊 买方略多 (${ratio.toFixed(1)}:1)`); }
      else if (ratio < 0.5) { score -= 5; reasons.push('📉 卖方压力大'); }
    }
  }

  return { score, reasons };
}

/**
 * 获取高潜力代币推荐列表
 * 从 DexScreener API 获取 BSC 热门代币并评分排序
 */
export async function getTokenRecommendations() {
  try {
    // 从 DexScreener 获取 BSC 热门代币
    const response = await fetch('https://api.dexscreener.com/token-profiles/latest/v1');
    if (!response.ok) throw new Error(`DexScreener API error: ${response.status}`);
    const data = await response.json();

    // 过滤 BSC 链代币
    let bscTokens = data.filter(t => 
      t.chainId === 'bsc' || 
      (t.tokenAddress && t.chainId === 'bsc')
    );

    // 如果没有足够的BSC代币，从 search 接口补充
    if (bscTokens.length < 5) {
      const searchResp = await fetch('https://api.dexscreener.com/latest/dex/search?q=BSC');
      if (searchResp.ok) {
        const searchData = await searchResp.json();
        if (searchData.pairs) {
          // 按交易量排序取前50
          const sorted = searchData.pairs
            .filter(p => p.chainId === 'bsc')
            .sort((a, b) => parseFloat(b.volume?.h24 || 0) - parseFloat(a.volume?.h24 || 0))
            .slice(0, 50);
          
          bscTokens = sorted.map(p => ({
            chainId: 'bsc',
            tokenAddress: p.baseToken?.address || '',
            symbol: p.baseToken?.symbol || '',
            name: p.baseToken?.name || '',
            liquidity: p.liquidity,
            volume: p.volume,
            priceChange: p.priceChange,
            txns: p.txns,
            pairCount: 1,
            url: p.url,
            priceUsd: p.priceUsd,
            fdv: p.fdv,
            pair: p,
          }));
        }
      }
    }

    // 对每个代币评分
    const scored = bscTokens.map(token => {
      const { score, reasons } = scoreToken(token);
      return {
        address: token.tokenAddress || '',
        symbol: token.symbol || token.baseToken?.symbol || '',
        name: token.name || token.baseToken?.name || '',
        score,
        reasons,
        liquidity: token.liquidity?.usd ? `$${(parseFloat(token.liquidity.usd)/1000).toFixed(0)}K` : '--',
        volume24h: token.volume?.h24 ? `$${(parseFloat(token.volume.h24)/1000).toFixed(0)}K` : '--',
        priceUsd: token.priceUsd || token.pair?.priceUsd || '--',
        fdv: token.fdv || '--',
        url: token.url || '',
      };
    });

    // 排序：分数从高到低
    scored.sort((a, b) => b.score - a.score);

    return {
      success: true,
      recommendations: scored.slice(0, 20), // 返回前20个
      total: scored.length,
      timestamp: new Date().toISOString(),
    };
  } catch (err) {
    console.error('[BAW] Token recommendation error:', err.message);
    return { success: false, error: err.message, recommendations: [] };
  }
}

/**
 * 快速获取 BNB 价格（用于报价显示）
 */
export async function getBnbPrice() {
  try {
    const resp = await fetch('https://api.binance.com/api/v3/ticker/price?symbol=BNBUSDT');
    const data = await resp.json();
    return parseFloat(data.price) || 0;
  } catch {
    return 0;
  }
}

export default {
  getBawStatus,
  getBawAddress,
  getBawBalance,
  getBawChains,
  getBawQuote,
  execBawSwap,
  getTokenRecommendations,
  getBnbPrice,
};
