# OKNC 自动交易系统 — 完整备份 (2026-05-09)

## 系统架构

```
                                   Nginx (443/80)
                                        │
                          ┌─────────────┴─────────────┐
                     /contract/ → :3000           /api/ → :3001
                          │                             │
              ┌───────────┴───────────┐                 │
              │                       │                 │
   oknc-autotrade.service      web3-autotrade.service
   (土狗+合约交易)                (Web3链上面板)
   port 3000                    port 3001
              │
              │
   mms-autotrade.service
   (做市系统)
   port 3002 (127.0.0.1)
```

## 端口总览

| 端口 | 服务 | 用途 |
|:----:|------|------|
| 3000 | oknc-autotrade | 土狗扫描 + 合约交易面板 |
| 3001 | web3-trading | Web3链上自动交易面板 |
| 3002 | mms-autotrade | 做市系统 (127.0.0.1) |

## 备份内容

```
backup-20260509-113146-full/
├── code/
│   ├── autotrade/          ← 主交易系统（土狗+合约+MMS）
│   └── web3-trading/       ← Web3面板（BAW集成）
├── config/
│   ├── nginx-trade.conf                    ← Nginx路由配置
│   ├── oknc-autotrade.service             ← systemd 土狗+合约服务
│   ├── web3-autotrade.service             ← systemd Web3服务
│   ├── mms-autotrade.service              ← systemd MMS服务
│   ├── env-autotrade.example              ← 脱敏环境变量
│   └── env-web3-trading.example           ← 脱敏环境变量
└── docs/
    (后续可放说明文档)
```

## 快速部署

```bash
# 1. 安装 Node.js (v22+) + Nginx
apt install nodejs nginx certbot python3-certbot-nginx

# 2. 部署 autotrade
cp -r code/autotrade /root/autotrade
cd /root/autotrade
npm install
cp config/env-autotrade.example .env
# 编辑 .env 填入真实密钥

# 3. 部署 web3-trading
cp -r code/web3-trading /root/web3-trading
cd /root/web3-trading
npm install
cp config/env-web3-trading.example .env
# 编辑 .env

# 4. 安装 systemd 服务
cp config/*.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now oknc-autotrade
systemctl enable --now web3-autotrade
systemctl enable --now mms-autotrade

# 5. Nginx
cp config/nginx-trade.conf /etc/nginx/sites-enabled/trade
nginx -t && systemctl reload nginx

# 6. SSL
certbot --nginx -d trade.oknc.club
```

## 关键API

| 端点 | 说明 |
|------|------|
| `GET /api/cex/strategy/status` | 合约策略状态 |
| `POST /api/cex/strategy/start` | 启动合约策略 |
| `POST /api/cex/strategy/stop` | 停止合约策略 |
| `GET /api/cex/status` | 合约总体状态 |
| `GET /api/cex/risk/status` | 风控状态 |
| `GET /api/status` | 土狗引擎状态 |

## 关键特性

- ✅ 合约策略**服务启动时自动启动**（BTC/USDT + ETH/USDT）
- ✅ 双密码认证（管理员 + 只读）
- ✅ 支持多交易所（币安/Gate/OKX）
- ✅ 土狗扫描（BSC链 PancakeSwap + Solana Jupiter）
- ✅ MMS做市系统
- ✅ BAW钱包集成
