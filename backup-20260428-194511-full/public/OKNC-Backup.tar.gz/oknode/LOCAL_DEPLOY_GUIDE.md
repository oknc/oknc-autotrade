# OKNC 本地部署工具包指引

> 在本地电脑上部署 OKNC 智能合约到 BSC 主网所需的全部工具和配置步骤

---

## 一、必备工具清单

| 工具 | 用途 | 下载地址 |
|------|------|----------|
| **MetaMask** 浏览器钱包 | 管理 BSC 账户、签署链上交易 | https://metamask.io/download/ |
| **Remix IDE**（网页版） | 在线编写/编译/部署 Solidity 合约 | https://remix.ethereum.org/ |
| **BSCScan** | 合约验证、查询交易记录 | https://bscscan.com/ |
| **PancakeSwap** | 添加/移除流动性 | https://pancakeswap.finance/liquidity |

---

## 二、MetaMask 配置

### 2.1 安装 MetaMask
1. 访问 https://metamask.io/download/
2. 选择对应浏览器（Chrome / Firefox / Edge / Brave）安装插件
3. 创建钱包 → 安全保存助记词（12/24个英文单词）
4. 设置钱包密码

### 2.2 添加 BSC 主网网络
打开 MetaMask → 设置 → 网络 → 添加网络，填写：

| 项目 | 内容 |
|------|------|
| 网络名称 | BNB Smart Chain |
| RPC URL | https://bsc-dataseed.binance.org |
| 链 ID | 56 |
| 货币符号 | BNB |
| 区块浏览器 | https://bscscan.com |

> 或者一键添加：打开 https://chainlist.org → 搜索 "BSC" → Connect Wallet → Add Chain

### 2.3 转入 BNB 作为 Gas 费
- 从交易所（币安等）提现 BNB 到 MetaMask 钱包地址
- 建议余额：**至少 0.5-1 BNB**（覆盖部署合约 + 添加流动性 + 测试交易）

---

## 三、Remix IDE 使用流程

### 3.1 打开 Remix
访问 https://remix.ethereum.org/

### 3.2 导入合约文件
1. 在左侧 File Explorer 中右键 contracts 文件夹 → New File
2. 创建三个文件：
   - `OKNC_BEP20.sol` — 新代币合约（带税版）
   - `OKNC_Swap.sol` — 映射合约
   - `OKNC_Whitepaper_V2.pdf`（不需要导入，本地保存即可）
3. 分别从以下网址复制合约代码粘贴进去：
   - https://www.oknode.club/contracts/OKNC_BEP20.sol
   - https://www.oknode.club/contracts/OKNC_Swap.sol

### 3.3 编译合约
1. 左侧选择 **Solidity Compiler** 图标
2. 编译器版本选 **0.8.20+**
3. 勾选 **Enable optimization** → 设为 **200**
4. 先选 `OKNC_BEP20.sol` → 点 **Compile OKNC_BEP20.sol**
5. 再选 `OKNC_Swap.sol` → 点 **Compile OKNC_Swap.sol**
6. 编译成功后，合约名旁显示绿色勾 ✅

### 3.4 部署准备
1. 左侧选择 **Deploy & Run Transactions** 图标
2. Environment 选 **Injected Provider - MetaMask**
3. 确认 MetaMask 弹出连接请求 → 确认连接
4. 右上角确认网络显示 **BNB Smart Chain**
5. Account 自动显示你 MetaMask 的当前地址

---

## 四、部署顺序（重要）

**必须先部署新 OKNC 合约，再部署映射合约。**

### Step 1: 部署新 OKNC（带税版）
1. Contract 选 `OKNC`
2. 构造函数参数：`_router = 0x10ED43C718714eb63d5aA57B78B54704E256024E`
   （PancakeSwap V2 Router 地址）
3. 点击 **Transact**
4. MetaMask 弹出确认窗口 → 确认
5. 等待交易完成（约 10-30 秒），**记录部署的合约地址**

### Step 2: 添加 PancakeSwap 流动性
1. 打开 https://pancakeswap.finance/liquidity
2. 连接 MetaMask
3. 点击 Add Liquidity
4. 选择 OKNC + BNB
5. 输入初始流动性金额，确认添加

### Step 3: 开启自动 Swap
1. 回到 Remix → 选择新 OKNC 合约
2. 调用 `setSwapEnabled(true)`

### Step 4: 设置 Swap 阈值
根据开盘价计算 1 BNB 对应的 OKNC 数量，调用 `setSwapThreshold()`

### Step 5: 部署映射合约
1. Contract 选 `OKNC_Swap`
2. 构造函数参数：
   - `_oldToken`: `0x1a3794ae4c629b646af10a765414547110305159`
   - `_newToken`: 你在 Step 1 部署的新 OKNC 地址
3. 点击 Transact → 确认

### Step 6: 存入新币储备
1. 切换到 Remix 中的新 OKNC 合约
2. 调用 `transfer(映射合约地址, 210000000000 * 10**18)`（存入全部 210 亿新币作为映射储备）

### Step 7: 开启映射
切换到映射合约 → 调用 `setSwapEnabled(true)`

---

## 五、BSCScan 验证合约

### 5.1 验证新 OKNC
1. 打开 https://bscscan.com → 搜新 OKNC 合约地址
2. 点 Contract → Verify and Publish
3. 选 Compiler: v0.8.20，License: MIT
4. Optimization: Yes (200 runs)
5. 粘贴合约代码 → 提交验证

### 5.2 验证映射合约
同上操作，选 `OKNC_Swap`

---

## 六、Gas 费用参考

当前 BSC Gas 极低（约 0.5 Gwei），部署成本很便宜：

| 操作 | 预估 Gas | 费用 (0.5 Gwei) |
|------|----------|-----------------|
| 部署新 OKNC 合约 | ~2,500,000 | ~0.0012 BNB ≈ **$0.80** |
| 添加流动性 | ~400,000 | ~0.0002 BNB ≈ **$0.13** |
| 部署映射合约 | ~1,500,000 | ~0.00075 BNB ≈ **$0.48** |
| 转入储备池 | ~300,000 | ~0.00015 BNB ≈ **$0.10** |
| **总计** | **~4,700,000** | **~$1.50** |

---

## 七、安全提醒

1. ✅ **助记词绝对不要泄露** — 任何人拿到你的助记词等于拿到你的钱包
2. ✅ **先说测试网再上主网** — 建议先在 BSC Testnet 部署测试一遍
3. ✅ **先小批量测试** — 正式开启映射前，用小号测试一笔完整的 approve → swap 流程
4. ✅ **保留备份** — 助记词、私钥、合约地址、ABI 都要备份保存
5. ✅ **Gas Price 不要设太低** — BSC 当前 gas 低但网络拥堵时失败率会上升

---

## 八、BSC Testnet 测试（可选）

先在测试网走一遍流程，确保一切正常：

| 项目 | 测试网信息 |
|------|-----------|
| 网络名称 | BSC Testnet |
| RPC URL | https://data-seed-prebsc-1-s1.binance.org:8545 |
| 链 ID | 97 |
| 测试币水龙头 | https://testnet.bnbchain.org/faucet-smart |
| PancakeSwap Testnet | https://pancake.kiemtienonline360.com/ |
| BSCScan Testnet | https://testnet.bscscan.com |
