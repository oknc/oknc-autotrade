// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title OKNC
 * @notice OKNC BEP20 代币 — 带买入分红、卖出&转账生态基金费用
 *
 * 代币参数：
 *   - 名称: OKNC
 *   - 符号: OKNC
 *   - 总供应量: 21,000,000,000 (210亿)
 *   - 小数位: 18
 *
 * 费用机制（永久固定，不可修改）：
 *   - 买入: 1% → 底池分红池（累积 OKNC → 自动 swap 为 BNB → 反射分红）
 *   - 卖出: 1% → 生态基金钱包
 *   - P2P转账: 0.5% → 生态基金钱包
 *
 * 底池分红实现：
 *   1. 买入累积 OKNC
 *   2. 达到阈值自动在 PancakeSwap V2 将 OKNC swap 为 BNB
 *   3. BNB 按持 OKNC 比例反射给所有持有者（类似 RFI 模型）
 *
 * 约束：
 *   无黑名单/白名单/暂停/可修改费率
 *   百分百透明
 */

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Address.sol";
import "@openzeppelin/contracts/utils/math/Math.sol";

interface IPancakeRouter {
    function swapExactTokensForETHSupportingFeeOnTransferTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external;
    function swapExactTokensForTokensSupportingFeeOnTransferTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external;
    function factory() external pure returns (address);
    function WETH() external pure returns (address);
    function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
}

interface IPancakeFactory {
    function createPair(address tokenA, address tokenB) external returns (address pair);
    function getPair(address tokenA, address tokenB) external view returns (address pair);
}

contract OKNC is ERC20, Ownable, ReentrancyGuard {
    using Address for address payable;

    // ─── 常量 ─────────────────────────────────────────────────────────────

    uint256 public constant BUY_FEE = 100;       // 买入费率: 1% (分母 10000)
    uint256 public constant SELL_FEE = 100;      // 卖出费率: 1%
    uint256 public constant TRANSFER_FEE = 50;   // P2P转账费率: 0.5%
    uint256 public constant FEE_DENOMINATOR = 10000;

    address public constant ECOSYSTEM_WALLET = 0x050493685cd466a7be41FA8275334dCAb105A54C;

    // ─── 状态变量 ─────────────────────────────────────────────────────────

    // PancakeSwap
    IPancakeRouter public pancakeRouter;
    address public pancakePair;

    // Swap 阈值: 累积多少 OKNC 后触发自动 swap（单位 wei）
    uint256 public swapThreshold;

    // 是否已启用 swap 功能（流动性添加后开启）
    bool public swapEnabled;

    // swap 中标志，防止递归
    bool private _inSwap;

    // 累积的买入分红池 OKNC
    uint256 public accumulatedForDividends;

    // 反射分红相关（类似 RFI 模型）
    uint256 public totalDividendBalance;          // 累计分配的 BNB (wei)
    uint256 public totalDividendPerToken;         // magnified 单位
    uint256 private constant MAGNIFIER = 2**128;

    // 每个地址的反射分红数据
    mapping(address => uint256) public rewardDebt;
    mapping(address => uint256) public dividendWithdraw;
    uint256 public totalRewardDistributed;

    // 排除费用/分红的地址
    mapping(address => bool) public isExcludedFromFee;
    mapping(address => bool) public isExcludedFromDividend;

    // ─── 事件 ─────────────────────────────────────────────────────────────

    event SwapAndSendDividend(uint256 tokensSwapped, uint256 bnbReceived, uint256 bnbDistributed);
    event FeeCollected(address indexed from, uint256 amount, uint256 feeType); // 1=buy, 2=sell, 3=transfer
    event ClaimDividend(address indexed user, uint256 amount);
    event SwapThresholdUpdated(uint256 newThreshold);

    // ─── 修饰器 ────────────────────────────────────────────────────────────

    modifier lockSwap() {
        _inSwap = true;
        _;
        _inSwap = false;
    }

    // ─── 构造函数 ──────────────────────────────────────────────────────────

    constructor(address _router)
        ERC20("OKNC", "OKNC")
        Ownable(msg.sender)
    {
        require(_router != address(0), "OKNC: invalid router");

        // 初始化 PancakeSwap Router (BSC主网: 0x10ED43C718714eb63d5aA57B78B54704E256024E)
        pancakeRouter = IPancakeRouter(_router);

        // 创建 OKNC/BNB LP 对
        pancakePair = IPancakeFactory(pancakeRouter.factory()).createPair(
            address(this),
            pancakeRouter.WETH()
        );

        // 默认排除自身、生态基金和零地址
        isExcludedFromFee[address(this)] = true;
        isExcludedFromFee[ECOSYSTEM_WALLET] = true;
        isExcludedFromFee[owner()] = true;
        isExcludedFromFee[address(0)] = true;
        isExcludedFromFee[address(0xdead)] = true;

        isExcludedFromDividend[address(0)] = true;
        isExcludedFromDividend[address(0xdead)] = true;
        isExcludedFromDividend[pancakePair] = true;
        isExcludedFromDividend[address(pancakeRouter)] = true;
        isExcludedFromDividend[address(this)] = true;

        // 初始 swap 阈值: 设为代币总供应量的 0.01%（约 2100 万 OKNC），
        // 部署后根据开盘价调用 setSwapThreshold 调整为 1 BNB 对应的具体代币数量
        // 例：1 OKNC = $0.0001, BNB = $600 → 1 BNB ≈ 6,000,000 OKNC
        swapThreshold = 21_000_000 * 10**18; // 初始 2100 万 OKNC 起

        // 铸造全部供应量给部署者
        _mint(msg.sender, 21_000_000_000 * 10**18);
    }

    receive() external payable {}

    // ─── 公开只读函数 ───────────────────────────────────────────────────

    /**
     * @notice 查询用户累积但尚未提取的 BNB 分红
     */
    function pendingDividend(address account) public view returns (uint256) {
        if (isExcludedFromDividend[account] || balanceOf(account) == 0) {
            return 0;
        }
        uint256 tokenBalance = balanceOf(account);
        uint256 totalReward = (tokenBalance * totalDividendPerToken) / MAGNIFIER;
        uint256 claimed = dividendWithdraw[account];
        if (totalReward <= claimed) {
            return 0;
        }
        return totalReward - claimed;
    }

    /**
     * @notice 设置 swap 阈值（仅 owner，部署初期可调）
     */
    function setSwapThreshold(uint256 threshold) external onlyOwner {
        require(threshold > 0, "threshold zero");
        swapThreshold = threshold;
        emit SwapThresholdUpdated(threshold);
    }

    /**
     * @notice 开启/关闭 swap 自动兑换（添加流动性后手动开启）
     */
    function setSwapEnabled(bool enabled) external onlyOwner {
        swapEnabled = enabled;
    }

    /**
     * @notice 批量设置排除费用的地址
     */
    function setExcludedFromFee(address account, bool excluded) external onlyOwner {
        isExcludedFromFee[account] = excluded;
    }

    /**
     * @notice 批量设置排除分红的地址
     */
    function setExcludedFromDividend(address account, bool excluded) external onlyOwner {
        isExcludedFromDividend[account] = excluded;
    }

    /**
     * @notice 手动触发 swap 并分红（当累积代币足够时）
     */
    function manualSwapAndDistribute() external onlyOwner {
        _swapAndDistribute(accumulatedForDividends);
    }

    /**
     * @notice 提取合约中意外收到的 BNB（紧急用途）
     */
    function rescueBNB(uint256 amount) external onlyOwner {
        require(amount <= address(this).balance, "insufficient bnb");
        payable(msg.sender).sendValue(amount);
    }

    // ─── ERC20 核心逻辑 ─────────────────────────────────────────────────

    function _transfer(address from, address to, uint256 amount) internal override {
        require(from != address(0), "ERC20: transfer from zero address");
        require(to != address(0), "ERC20: transfer to zero address");
        require(amount > 0, "transfer amount zero");

        // 计算费用
        (uint256 fee, uint256 feeType) = _calculateFee(from, to, amount);
        uint256 transferAmount = amount - fee;

        if (fee > 0) {
            // 收取费用到合约自身
            super._transfer(from, address(this), fee);

            if (feeType == 1) {
                // 买入：累积到分红池
                accumulatedForDividends += fee;
                emit FeeCollected(from, fee, 1);
            } else if (feeType == 2) {
                // 卖出：转给生态基金
                super._transfer(address(this), ECOSYSTEM_WALLET, fee);
                emit FeeCollected(from, fee, 2);
            } else if (feeType == 3) {
                // 转账：转给生态基金
                super._transfer(address(this), ECOSYSTEM_WALLET, fee);
                emit FeeCollected(from, fee, 3);
            }
        }

        // 执行转账
        super._transfer(from, to, transferAmount);

        // 分红会计更新
        _updateDividendAccounting(from);
        _updateDividendAccounting(to);

        // 尝试自动 swap + 分红（买入时触发）
        if (feeType == 1 && !_inSwap && swapEnabled && accumulatedForDividends >= swapThreshold) {
            uint256 toSwap = accumulatedForDividends;
            _swapAndDistribute(toSwap);
        }
    }

    // ─── 费用计算 ──────────────────────────────────────────────────────

    function _calculateFee(address from, address to, uint256 amount)
        internal
        view
        returns (uint256 fee, uint256 feeType)
    {
        // 排除费用的地址不扣费
        if (isExcludedFromFee[from] || isExcludedFromFee[to]) {
            return (0, 0);
        }

        // 判断交易类型
        if (from == pancakePair) {
            // 买入
            fee = (amount * BUY_FEE) / FEE_DENOMINATOR;
            feeType = 1;
        } else if (to == pancakePair) {
            // 卖出
            fee = (amount * SELL_FEE) / FEE_DENOMINATOR;
            feeType = 2;
        } else {
            // P2P 转账
            fee = (amount * TRANSFER_FEE) / FEE_DENOMINATOR;
            feeType = 3;
        }
        return (fee, feeType);
    }

    // ─── Swap & 分红 ──────────────────────────────────────────────────

    function _swapAndDistribute(uint256 tokenAmount) internal nonReentrant lockSwap {
        require(tokenAmount > 0, "no tokens to swap");
        require(tokenAmount <= accumulatedForDividends, "exceeds accumulated");

        // 扣除累积
        accumulatedForDividends -= tokenAmount;

        // 授权 Router 代币
        _approve(address(this), address(pancakeRouter), tokenAmount);

        // 记录 swap 前的 BNB 余额
        uint256 initialBNBBalance = address(this).balance;

        // 在 PancakeSwap 上 OKNC → BNB
        address[] memory path = new address[](2);
        path[0] = address(this);
        path[1] = pancakeRouter.WETH();

        try pancakeRouter.swapExactTokensForETHSupportingFeeOnTransferTokens(
            tokenAmount,
            0, // 最小输出设为0，可通过 MEV 保护（建议前端增加滑点参数）
            path,
            address(this),
            block.timestamp + 300
        ) {
            // 计算获得的 BNB
            uint256 bnbReceived = address(this).balance - initialBNBBalance;

            if (bnbReceived > 0) {
                // 将 BNB 按持 OKNC 比例分配
                _distributeDividend(bnbReceived);
                emit SwapAndSendDividend(tokenAmount, bnbReceived, bnbReceived);
            }
        } catch {
            // swap 失败时，将代币归还累积池
            accumulatedForDividends += tokenAmount;
        }
    }

    /**
     * @notice 反射分红：BNB 按持 OKNC 比例分配
     * BNB 留在合约中，用户通过 claimDividend() 提取
     */
    function _distributeDividend(uint256 bnbAmount) internal {
        if (bnbAmount == 0 || totalSupply() == 0) return;

        uint256 totalExcludedBalance = 0;
        // 计算被排除分红的地址的持币量
        // 简化实现：实际生产环境建议用映射迭代，但这里用更安全方案
        // 仅排除 LP pair 和合约自身
        if (isExcludedFromDividend[pancakePair]) {
            totalExcludedBalance += balanceOf(pancakePair);
        }
        if (isExcludedFromDividend[address(this)]) {
            totalExcludedBalance += balanceOf(address(this));
        }
        if (isExcludedFromDividend[ECOSYSTEM_WALLET]) {
            totalExcludedBalance += balanceOf(ECOSYSTEM_WALLET);
        }

        uint256 effectiveSupply = totalSupply() - totalExcludedBalance;
        if (effectiveSupply == 0) return;

        // magnified 增量
        uint256 dividendPerToken = (bnbAmount * MAGNIFIER) / effectiveSupply;
        totalDividendPerToken += dividendPerToken;
        totalDividendBalance += bnbAmount;
    }

    /**
     * @notice 用户提取累积的 BNB 分红
     */
    function claimDividend() external nonReentrant {
        _claimDividend(msg.sender);
    }

    function _claimDividend(address account) internal {
        uint256 pending = pendingDividend(account);
        require(pending > 0, "no pending dividend");
        require(address(this).balance >= pending, "insufficient bnb in contract");

        dividendWithdraw[account] += pending;
        totalRewardDistributed += pending;
        totalDividendBalance -= pending;

        payable(account).sendValue(pending);
        emit ClaimDividend(account, pending);
    }

    /**
     * @notice 批量提取（Gas 优化）
     */
    function claimDividendBatch(address[] calldata accounts) external onlyOwner {
        for (uint256 i = 0; i < accounts.length; i++) {
            if (pendingDividend(accounts[i]) > 0) {
                _claimDividend(accounts[i]);
            }
        }
    }

    /**
     * @notice 更新分红会计（持币变动时调用）
     */
    function _updateDividendAccounting(address account) internal {
        if (account == address(0)) return;
        if (isExcludedFromDividend[account]) return;

        uint256 pending = pendingDividend(account);
        if (pending > 0 && isExcludedFromFee[account]) {
            // 如果是排除费用的地址（如 owner），不自动 claim
            return;
        }
        if (pending > 0) {
            // 自动转入 rewardDebt
            rewardDebt[account] = (balanceOf(account) * totalDividendPerToken) / MAGNIFIER;
        }
    }
}
