# OKNC BEP20 代币部署说明

## 概要

| 项 | 值 |
|---|---|
| 代币名称 | OKNC |
| 代币符号 | OKNC |
| 总供应量 | 21,000,000,000 (210亿) |
| 小数位 | 18 |
| 网络 | BSC 主网 (Chain ID: 56) |
| 标准 | BEP20 |
| PancakeSwap Router | `0x10ED43C718714eb63d5aA57B78B54704E256024E` |
| 生态基金钱包 | `0x050493685cd466a7be41FA8275334dCAb105A54C` |

---

## 一、合约关键机制

### 交易费率（永久固定）

| 操作 | 费率 | 去向 |
|------|------|------|
| 买入 | 1% (100/10000) | 底池分红池 → swap 为 BNB → 反射分红 |
| 卖出 | 1% (100/10000) | 生态基金钱包 |
| P2P转账 | 0.5% (50/10000) | 生态基金钱包 |

### 分红机制
- 买入累积的 OKNC 达到 `swapThreshold` 时自动在 PancakeSwap swap 为 BNB
- BNB 按持 OKNC 比例反射分配，用户通过 `claimDividend()` 提取
- 默认 `swapThreshold = 总供应量 × 0.001% ≈ 210,000 OKNC`
- 部署后可用 `setSwapThreshold()` 调整

### 安全特性
- ✅ 防递归：`lockSwap` 修饰器 + `ReentrancyGuard`
- ✅ 防机器人攻击：`setSwapEnabled` 先关后开
- ✅ 无黑名单/白名单/暂停
- ✅ 费率不可修改

---

## 二、部署前准备

### 1. 钱包准备
- 使用 MetaMask 或类似钱包
- 切换到 **BSC 主网**
- 确保有足够 **BNB** 支付 Gas（建议至少 0.5 ~ 1 BNB）

### 2. 在 Remix 中打开合约
1. 打开 https://remix.ethereum.org/
2. 在 contracts 目录下创建 `OKNC_BEP20.sol`，粘贴合约代码
3. 在 Solidity Compiler 标签页：
   - 编译器版本选择 `0.8.20+`
   - 勾选 "Enable optimization"（建议 200 runs）
4. 编译合约（确认无错误）

### 3. 添加 OpenZeppelin 库
Remix 会自动从 NPM 加载 `@openzeppelin/contracts`。如不能自动加载：
- 在 Remix 的 File Explorer 中右键 → "Flattener" → 手动整合
- 或者使用 hardhat-flatten 后粘贴单文件

---

## 三、部署步骤

### Step 1: 部署合约
1. 在 Deploy & Run Transactions 标签页
2. Environment 选择 **Injected Provider - MetaMask**
3. Contract 选择 `OKNC`
4. 构造函数参数：`_router = 0x10ED43C718714eb63d5aA57B78B54704E256024E`
   > 这是 PancakeSwap V2 Router 地址。
5. 点击 **Transact** → MetaMask 确认交易
6. 等待交易确认，**记录部署的合约地址**

### Step 2: 添加 PancakeSwap V2 流动性
1. 打开 https://pancakeswap.finance/liquidity
2. 连接部署钱包
3. 点击 "Add Liquidity"
4. 选择 **OKNC** 和 **BNB**
   - 如果 OKNC 未自动显示，粘贴合约地址手动导入
5. 输入初始流动性金额（建议：按预估开盘价提供流动性）
   > 例如：代币总量 210 亿，想初始市值 $10,000
   > 假设 BNB = $600 → 提供 ≈ 16.7 BNB + 对应的 OKNC
6. 确认添加

### Step 3: 开启自动 Swap
1. 在 Remix 中，连接已部署的合约
2. 调用 `setSwapEnabled(true)`（仅 owner 可调用）
3. 此时买入触发自动 swap + 分红开始运作

### Step 4: 设置 Swap 阈值

**参考计算：1 BNB 对应的 OKNC 代币数量**

例：若开盘时 1 OKNC ≈ $0.000005 (即初始市值 ~$10,500)，BNB = $600
→ 1 BNB 价值 ≈ 120,000,000 (1.2亿) OKNC

公式：`swapThreshold = BNB价格 ÷ OKNC价格`

调用 `setSwapThreshold(120_000_000 * 10**18)` 设置

> ⚠️ 阈值设置过小会导致频繁触发 swap 消耗大量 Gas
> 建议：起初设大一些，等社区活跃后根据情况调小

### Step 5: （可选）配置参数
- `setExcludedFromFee(address, bool)` — 添加/移除费用排除地址
- `setExcludedFromDividend(address, bool)` — 添加/移除分红排除地址
- `manualSwapAndDistribute()` — 手动触发 swap + 分红

---

## 四、部署后检查清单

- [ ] 合约已部署到 BSC 主网
- [ ] 流动性已添加
- [ ] `swapEnabled = true`
- [ ] 生态基金地址确认无误
- [ ] 小批量测试买入（检查费用走向）
- [ ] 小批量测试卖出（检查费用走向）
- [ ] 测试 P2P 转账（费率 0.5%）
- [ ] 底池分红自动触发是否正常
- [ ] BSCScan 验证合约源码（见下一节）

---

## 五、BSCScan 合约验证

1. 打开 https://bscscan.com/ → 搜索合约地址
2. 点击 **Contract** → **Verify and Publish**
3. 选择：
   - Compiler: `v0.8.20+commit.a1b79de6`（或对应版本）
   - License: **MIT License** (MIT)
   - Optimization: Yes (200 runs)
4. 粘贴合约代码
5. 提交验证

> ✅ BSCScan 验证后合约完全透明公开，任何人可查代码与交易

---

## 六、Gas 预估

| 操作 | 预估 Gas |
|------|----------|
| 部署合约 | ~2,500,000 ~ 3,500,000 |
| 添加流动性 | ~400,000 ~ 600,000 |
| 转账（普通） | ~50,000 ~ 80,000 |
| 买入（含分红更新） | ~100,000 ~ 200,000 |
| 自动 Swap | ~300,000 ~ 500,000 |
| 提取分红 (claimDividend) | ~80,000 ~ 150,000 |

> 实际 Gas 取决于网络拥堵和合约状态。

---

## 七、常见问题

### Q: 为什么买入时分红未自动触发？
A: 需要满足：① `swapEnabled = true` ② 累积代币 ≥ `swapThreshold` ③ 非 swap 中

### Q: 分红如何提取？
A: 用户调用 `claimDividend()` 即可提取累积的 BNB 分红。Owner 可调用 `claimDividendBatch()` 批量提取。

### Q: 如何查询可提取分红？
A: 调用 `pendingDividend(address)` 查看用户累积未提取的 BNB。

### Q: 如果 swap 失败会怎样？
A: 累积的 OKNC 会返还到 `accumulatedForDividends`，下次满足条件时继续尝试。

### Q: 合约中意外收到的 BNB 如何处理？
A: Owner 可调用 `rescueBNB(uint256)` 提取（仅用于紧急情况）。

---

## 八、合约公开接口速览

### Read
- `BUY_FEE` / `SELL_FEE` / `TRANSFER_FEE`
- `ECOSYSTEM_WALLET`
- `swapThreshold`
- `swapEnabled`
- `accumulatedForDividends`
- `pendingDividend(address)` → BNB 分红
- `totalDividendBalance` — 累计未分配 BNB
- `totalDividendPerToken` — magnified 分红索引

### Write (Public)
- `claimDividend()` — 提取分红

### Write (Owner)
- `setSwapThreshold(uint256)`
- `setSwapEnabled(bool)`
- `setExcludedFromFee(address, bool)`
- `setExcludedFromDividend(address, bool)`
- `manualSwapAndDistribute()`
- `rescueBNB(uint256)`
- `claimDividendBatch(address[])`

---
